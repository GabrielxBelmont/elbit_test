import * as React from 'react';



/**
 * Hook para contagem de tempo semelhante a setInteval
 * @param callback função a ser execultada a cada intervalo de tempo
 * @param time tempo dos intervalos em milisegundos
*/
function use7Boom(
    time=1000,
    initialNumber = 0
){

    const [boom, setBoom] = React.useState([])
    const [current, setCurrent] = React.useState(1)
    let state = "noStarted";
    let timeHandle;
    function sequence(num) {
        let arr = []
        for(let i = initialNumber; i <= num; i++) {
            arr.push(i)
            if (arr[i]%7==0){
                arr.pop()
                arr.push(-1)
            }

        }
        setCurrent(num)
        setBoom(arr)
    }

    function add1 () {
        console.log("adding")
        sequence(current + 1)
    }


    return { initialNumber, boom, sequence, add1, current }

}


export default use7Boom;