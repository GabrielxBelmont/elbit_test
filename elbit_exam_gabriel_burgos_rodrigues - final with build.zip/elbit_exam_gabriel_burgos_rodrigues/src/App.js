import React, { useEffect } from 'react';
import './App.css';
import use7Boom from './hooks/use7Boom'

function App() {
  const { sequence, boom, add1, current } = use7Boom()
  useEffect(() => {
    sequence(0)
  }, [])
  useEffect(() => {
    if (current % 7 == 0) {
      document.title ="Boom!"
    } else{
      document.title ="Counting"
    }
  }, [current])
  return (
    <div className="App">
      <header className="">
        ElbitTest
      </header>
      <div>
      <button onClick={add1}>Increase</button>
      <label>{current}</label>
      </div>
      <div class="list">
        { boom.map((int, index) => {
          if (int != -1) {
            return (
              <div key={index}>
                { int  }
              </div>
            )
          }
          else {
            return (
              <div key={index} className="grey">
                boom
              </div>
            )
          }

        }) }
      </div>


    </div>
  );
}

export default App;
